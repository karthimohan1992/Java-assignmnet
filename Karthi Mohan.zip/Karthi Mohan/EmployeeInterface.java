package com.karthi.assessment;

public interface EmployeeInterface {
  boolean findEmployee(int id);
}
