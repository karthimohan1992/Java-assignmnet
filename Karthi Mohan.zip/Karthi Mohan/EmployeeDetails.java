package com.karthi.assessment;

import java.util.ArrayList;

public abstract class EmployeeDetails {
   abstract void printEmployeesDetails(ArrayList<EmployeeModel> empModelList);
}
